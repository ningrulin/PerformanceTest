Hardly documented answers
=========================

* How to include a literal bracket in a SIP message?

  You can use `\x5b` instead of `[`. 
